from pathlib import Path
import json
import subprocess
from zipfile import ZipFile,ZIP_STORED

work=Path(__file__).resolve().parent
workspace=work.parents[1]
output=workspace/'outputs'
ffmpeg=next((workspace/'work/video-deps/imageio_ffmpeg/binaries').glob('ffmpeg*.exe'))
source=output/'Escape_Dimension_발표용_튜토리얼_90초.mp4'
clips=output/'Escape_Dimension_기능별_시연'
clips.mkdir(exist_ok=True)
chapters=[
 ('01_2D_이동과_점프',4,12,'2D에서는 좌우로 이동하고 낮은 점프로 상자에 올라갑니다. 하체의 좌우 방향을 유지하면서 상체로 위아래를 조준합니다.'),
 ('02_사격과_이동중_장전',16,12,'탄창은 6발이고 총 보유량은 최대 42발입니다. 이동 중에도 상체의 장전과 하체의 걷기 모션을 함께 보여줍니다.'),
 ('03_3D_자유이동',28,10,'3을 누르면 같은 화면을 바닥으로 해석합니다. 8방향으로 벽을 우회하고 마우스 방향을 자유롭게 바라봅니다.'),
 ('04_상자_투척과_낙하공격',38,13,'E로 집고 Q로 던집니다. 3D에서 놓은 상자는 2D로 전환하면 중력을 받아 떨어지며 적을 공격합니다.'),
 ('05_4D_정지와_시간이동',51,18,'4D에서 멈추면 탄환도 멈추고, 움직이면 다시 진행합니다. 최근 4초의 위치를 선택해 이동하면 3D로 돌아오며 한 살을 먹습니다.'),
 ('06_칼_적과_우회추적',69,13,'빠른 칼 적이 벽을 우회해 추적합니다. 경로가 보이도록 앞부분은 0.25배속으로 보여주며 조준해 처치합니다.'),
]
files=[]
for name,start,duration,script in chapters:
    target=clips/(name+'.mp4')
    subprocess.run([str(ffmpeg),'-hide_banner','-loglevel','error','-y','-ss',str(start),'-i',str(source),
        '-t',str(duration),'-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p',
        '-c:a','aac','-b:a','128k','-movflags','+faststart',str(target)],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    files.append(target)
    print(json.dumps({'clip':name,'seconds':duration}),flush=True)
text=['# Escape Dimension 기능별 발표 시연 영상','',
      '설명할 기능에 맞는 MP4만 열어 재생하면 됩니다. 각 영상에는 조작 키와 설명 자막, 게임 효과음이 포함되어 있습니다. 별도의 음성 내레이션은 없습니다.','',
      '전체 연결본은 정확히 90초이며 기능별 영상은 시작·마무리 화면을 제외했습니다. 시연 장면은 기존 게임 코드로 실행한 기능별 전용 배치입니다. 각 장면 사이에는 상태가 초기화됩니다.','',
      '현재 3주차이며 4주차 시간 조작 분량까지 선행 구현한 기준입니다.','']
for name,start,duration,script in chapters:
    text.extend(['## '+name,'',f'전체 영상 {start//60:02d}:{start%60:02d}부터 / 길이 {duration}초','',script,''])
guide=clips/'발표_순서와_설명.md'
guide.write_text('\n'.join(text),encoding='utf-8')
archive=output/'Escape_Dimension_기능별_시연영상.zip'
with ZipFile(archive,'w',compression=ZIP_STORED) as z:
    for f in files+[guide]:z.write(f,arcname=f.name)
report=[]
for f in [source]+files:
    result=subprocess.run([str(ffmpeg),'-hide_banner','-loglevel','error','-i',str(f),'-f','null','-'],
                          capture_output=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    report.append({'file':f.name,'bytes':f.stat().st_size,'decoded':True})
(work/'delivery-check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'clips':len(files),'archive_bytes':archive.stat().st_size,'decoded_files':len(report)}))
