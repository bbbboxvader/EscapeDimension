"""Capture scripted, isolated demonstrations using the game's actual simulation.

The game source/assets stay untouched. Scenes reset between demonstrations.
"""
from __future__ import annotations
import argparse
from array import array
import ctypes
import json
import math
from pathlib import Path
import subprocess
import sys
import wave

WORK=Path(__file__).resolve().parent
WORKSPACE=WORK.parents[1]
GAME=Path('C:/Users/tedu0/OneDrive/바탕 화면/Escape Dimension/Escapse Dimension')
sys.path.insert(0,str(GAME))
from core import Game, Actor, Crate, Bullet, BOTTOM, PLAYER_HALF

FPS=30
SCENES=[('intro',4),('movement',12),('combat',12),('free',10),
        ('gravity',13),('time',18),('knife',13),('outro',8)]
TITLE={
 'movement':'01  좌우 이동과 낮은 점프',
 'combat':'02  상체 조준과 이동 중 장전',
 'free':'03  같은 화면을 바닥으로 읽는 3D',
 'gravity':'04  상자 집기·투척과 중력 전환',
 'time':'05  4D 정지와 과거 위치 이동',
 'knife':'06  빠른 칼 적과 벽 우회 추적',
}

class Demo:
    def __init__(self,name):
        self.name=name
        self.frame=-1
        self.fired=set()
        self.audio=[]
        self.checks={}
        self.move=(0,0)
        self.aim=(900,260)
        self.keys=''
        self.caption=''
        self.setup()

    def room(self,spawn=(300,176),enemies=(),crates=(),obstacles=(),mode=2):
        self.g=Game()
        self.g.levels=[{'name':'기능별 튜토리얼 시연','tag':'PRESENTATION / TUTORIAL',
          'hint':'','spawn':list(spawn),'enemies':[list(e) for e in enemies],
          'crates':[list(c) for c in crates],'obstacles':[list(o) for o in obstacles],
          'ammo':[],'zones':[],'marks':[]}]
        self.g.start()
        if mode!=2:self.g.set_mode(mode)
        self.g.grace=1000
        self.g.hint_left=0
        self.g.next_room=lambda:False
        self.g.events.clear()
        self.start_x,self.start_y=self.g.player.x,self.g.player.y
        return self.g

    def setup(self):
        if self.name=='movement':
            self.room(crates=[(550,177)])
        elif self.name=='combat':
            self.room(enemies=[(850,176,'sentry')])
        elif self.name=='free':
            self.room(obstacles=[(570,154,630,380)])
            self.g.room['zones']=[[840,390,1100,540,'3D : FREE MOVEMENT']]
        elif self.name=='gravity':
            self.room(spawn=(280,176),crates=[(345,177)],mode=3)
        elif self.name=='time':
            self.room(spawn=(260,176),mode=3)
            self.g.player.y=260
            self.g.history.clear()
            self.g.history.append((0.,260.,260.))
        elif self.name=='knife':
            self.room(spawn=(1040,176),enemies=[(270,176,'knife')],
                      obstacles=[(570,230,650,430)],mode=3)
            self.g.player.y=320
            self.g.enemies[0].y=320
            self.g.grace=0
        else:
            self.room()

    def once(self,t,at,name,action):
        if t>=at and name not in self.fired:
            self.fired.add(name)
            return action()

    def step(self,frame):
        self.frame=frame
        t=frame/FPS
        g=self.g
        self.move=(0,0)
        self.aim=(g.player.x+260,g.player.y+24)
        self.keys=''
        firing=False
        dt=1/FPS
        if self.name=='movement':
            self.caption='A / D는 좌우 이동, Space는 상자에 겨우 오를 높이의 점프입니다.'
            if .7<=t<1.5:self.move=(1,0);self.keys='D'
            if 1.7<=t<2.15:self.move=(1,0);self.keys='D + SPACE'
            self.once(t,1.7,'jump',lambda:self.checks.update(jump_started=g.jump()))
            if 2.3<t<3.0 and g.grounded and g.player.y>210:self.checks['landed_on_crate']=True
            if 3.7<=t<5.1:self.move=(1,0);self.keys='D'
            if 5.8<=t<7.1:self.move=(-1,0);self.keys='A'
            if 7.6<=t<8.25:self.move=(-1,0);self.keys='A + SPACE'
            self.once(t,7.6,'jump_back',g.jump)
            if t>=9:
                self.aim=(g.player.x+220,g.player.y+210*math.sin((t-9)*1.8))
                self.caption='하체는 좌우 방향을 유지하고, 상체가 위아래 조준을 따라갑니다.'
                self.keys='마우스 위 / 아래'
        elif self.name=='combat':
            self.caption='탄창 6발 + 예비탄 36발, 탄약 보유량은 합계 최대 42발입니다.'
            if t<2.8:
                self.aim=(g.player.x+260,g.player.y+50+165*math.sin(t*2.3))
                if any(a<=t<a+.15 for a in (.8,1.5,2.2)):
                    firing=True;self.keys='마우스 조준 + 왼쪽 클릭'
            elif t<4.0:
                self.aim=(850,200);firing=True;self.keys='왼쪽 클릭'
            self.once(t,4.0,'reload',lambda:self.checks.update(reload_started=g.reload()))
            if 4.0<=t<5.4:
                self.move=(1,0);self.keys='D + R'
                self.caption='장전 중에도 이동합니다. 상체는 장전하고 하체는 걷습니다.'
            if t>5.4:self.checks['reload_completed']=g.magazine==6
            if 6.2<t<6.6:firing=True;self.aim=(950,410);self.keys='왼쪽 클릭'
            self.once(t,6.7,'reload_left',g.reload)
            if 6.7<=t<8.1:
                self.move=(-1,0);self.keys='A + R'
                self.aim=(180,200)
                self.caption='왼쪽으로 이동하며 장전할 때도 걷기와 장전 모션이 함께 보입니다.'
            if t>=8.1:
                self.caption='걷기·장전·적 사망 모션이 실제 전투 동작에 연결되어 있습니다.'
                self.keys='탄약과 장전 상태 확인'
            self.checks['enemy_defeated']=not g.enemies[0].alive
        elif self.name=='free':
            self.caption='3을 누르면 같은 종이를 바닥으로 해석하며 8방향으로 이동합니다.'
            self.once(t,1.1,'mode3',lambda:self.checks.update(switched_3d=g.set_mode(3)))
            if 1.4<=t<3.3:self.move=(1,1);self.keys='3 → W + D'
            if 3.3<=t<4.9:self.move=(1,0);self.keys='D'
            if 4.9<=t<5.7:self.move=(0,-1);self.keys='S'
            if 6.1<=t<6.8:self.move=(-1,1);self.keys='W + A'
            if t>=6.8:
                self.aim=(g.player.x+180*math.cos(t*2),g.player.y+24+130*math.sin(t*2))
                self.keys='마우스로 모든 방향 조준'
                self.caption='2D 화면을 유지하면서 이동 규칙과 바라보는 방향만 바뀝니다.'
            self.checks['went_around_wall']=g.player.x>670 or self.checks.get('went_around_wall',False)
            self.checks['vertical_movement']=g.player.y>400 or self.checks.get('vertical_movement',False)
        elif self.name=='gravity':
            self.caption='가까운 상자는 E로 집고, Q로 조준 방향에 던집니다.'
            self.once(t,1.0,'pickup',lambda:self.checks.update(picked_up=g.pickup()))
            if 1.4<=t<2.4:self.move=(1,1);self.keys='E → W + D'
            self.aim=(900,370)
            self.once(t,2.6,'throw',lambda:self.checks.update(thrown=g.throw(self.aim)))
            if 2.6<=t<4.5:self.keys='Q  투척'
            if t>=5.2 and 'drop_setup' not in self.fired:
                self.fired.add('drop_setup')
                self.room(spawn=(310,176),enemies=[(840,176,'sentry')],mode=3)
                g=self.g
                g.crates=[Crate(840,445)]
                self.checks['enemy_alive_before_drop']=g.enemies[0].alive
            if t>=5.2:
                self.aim=(840,205)
                self.caption='3D에서 바닥에 놓인 듯 보이는 상자가, 2D에서는 높은 곳의 물체가 됩니다.'
                self.keys='3D 배치 확인'
            self.once(t,7.8,'gravity',lambda:g.set_mode(2))
            if t>=7.8:
                self.caption='2를 눌러 중력을 켜면 상자가 떨어져 아래의 적을 공격합니다.'
                self.keys='2  중력 전환'
                self.checks['gravity_kill']=not g.enemies[0].alive
            if t>=10:
                self.caption='배경은 그대로입니다. 높이와 바닥이라는 해석이 바뀌어 전투 방법이 달라집니다.'
        elif self.name=='time':
            self.caption='먼저 3D로 이동해 최근 4초의 위치 기록을 만듭니다.'
            if .8<=t<2.7:self.move=(1,.5);self.keys='W + D  위치 기록'
            self.once(t,2.8,'incoming',lambda:g.bullets.append(Bullet(1100,365,-320,0,'enemy',8)))
            self.once(t,3.2,'time4',lambda:self.checks.update(entered_4d=g.set_mode(4)))
            if 3.2<=t<6:
                self.caption='4를 누른 뒤 멈추면 적과 탄환도 정지합니다. 10초 제한은 계속 줄어듭니다.'
                self.keys='4 → 손을 떼어 정지'
            if 6<=t<6.55:
                self.move=(0,1);self.keys='W  세계가 다시 움직임'
                self.caption='플레이어가 움직이는 동안에만 세계와 탄환이 다시 진행합니다.'
            if 6.55<=t<8.2:
                self.caption='다시 멈추면 탄환도 멈춥니다. 움직일 시점을 직접 선택합니다.'
                self.keys='입력 없음  WORLD PAUSED'
            if 8.2<=t<11.2:
                points=g.rewind_points()
                if points:
                    choices=[i for i,p in enumerate(points) if p[3]]
                    if choices:g.select_rewind(index=choices[min(len(choices)-1,int((t-8.2)*2))])
                self.caption='휠이나 방향키로 0.5초 간격의 과거 위치를 고릅니다.'
                self.keys='휠 / ← →  과거 잔상 선택'
            if t>=11.2 and 'rewind' not in self.fired:
                self.fired.add('rewind')
                points=g.rewind_points()
                safe=[i for i,p in enumerate(points) if p[3]]
                if safe:g.select_rewind(index=safe[-1])
                old=g.player.x,g.player.y
                ok=g.rewind()
                self.checks.update(rewind_succeeded=ok,rewind_changed_position=math.dist(old,(g.player.x,g.player.y))>60,
                                   returned_to_3d=g.mode==3,age_cost=g.age==21)
            if t>=11.2:
                self.caption='Enter로 선택한 위치로 이동하면 즉시 3D로 돌아오고, 나이를 한 살 먹습니다.'
                self.keys='Enter  시간 이동 / AGE 20 → 21'
            if 13.1<=t<14.3:self.move=(0,-1)
            if 14.3<=t<15.5:self.move=(1,0)
            if t>=15.5:
                self.caption='되돌리는 것은 플레이어 위치입니다. 탄약·적의 상태는 그대로 유지됩니다.'
                self.keys='4D 최대 10초 / 최근 4초 위치 선택'
        elif self.name=='knife':
            dt=1/120
            self.caption='칼 적은 빠르게 추적합니다. 벽을 만나면 모서리를 돌아 접근합니다. (0.25배속)'
            self.keys='입력 없음  적의 우회 경로 관찰'
            enemy=g.enemies[0]
            if enemy.y>440:self.checks['knife_routed_around_wall']=True
            if t>=4.5:
                self.aim=(enemy.x,enemy.y+20)
                self.keys='마우스 조준'
            if t>=5.0 and enemy.alive:
                firing=True;self.keys='왼쪽 클릭  추적 적 처치'
            if not enemy.alive:
                self.checks['knife_defeated']=True
                self.caption='벽을 뚫지 않고 우회한 칼 적을 조준해 처치합니다. (0.25배속)'
            if t>=10.5:
                dt=1/FPS
                self.caption='빠른 추적, 우회 AI, 적의 사망 모션을 한 장면에서 확인할 수 있습니다.'
                self.keys='시연 속도 1배속'
        g.tick(dt,self.move,self.aim,firing)
        if self.name=='time' and 3.3<t<6:
            self.checks['world_frozen']=g.time_frozen
            if g.bullets:
                last=self.checks.get('frozen_bullet_x',g.bullets[0].x)
                self.checks['bullet_held']=abs(last-g.bullets[0].x)<.01
                self.checks['frozen_bullet_x']=g.bullets[0].x
        if self.name=='combat' and g.reload_left>0 and g.player.moving:
            self.checks['walking_while_reloading']=True
        self.checks['survived']=g.state=='playing'
        for event in g.events:
            if event not in ('clear','pickup') or self.name=='gravity':self.audio.append((t,event))
        g.events.clear()
        g.hint_left=0

    def verify(self):
        required={
          'movement':['jump_started','landed_on_crate'],
          'combat':['reload_started','reload_completed','enemy_defeated','walking_while_reloading'],
          'free':['switched_3d','went_around_wall','vertical_movement'],
          'gravity':['picked_up','thrown','enemy_alive_before_drop','gravity_kill'],
          'time':['entered_4d','world_frozen','bullet_held','rewind_succeeded','rewind_changed_position','returned_to_3d','age_cost'],
          'knife':['knife_routed_around_wall','knife_defeated'],
        }.get(self.name,[])+['survived']
        failed=[k for k in required if self.checks.get(k) is not True]
        return {'scene':self.name,'status':'fail' if failed else 'pass','failed':failed,'checks':self.checks}

def preflight():
    reports=[]
    for name,seconds in SCENES:
        demo=Demo(name)
        for f in range(seconds*FPS):demo.step(f)
        reports.append(demo.verify())
    (WORK/'preflight.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
    print(json.dumps(reports),flush=True)
    return all(r['status']=='pass' for r in reports)

def mix_audio(events,path):
    rate=22050
    samples=array('i',[0])*(rate*90)
    cache={}
    for when,name in events:
        source=GAME/'assets'/(name+'.wav')
        if not source.exists():continue
        if name not in cache:
            with wave.open(str(source),'rb') as w:
                assert w.getnchannels()==1 and w.getsampwidth()==2 and w.getframerate()==rate
                data=array('h');data.frombytes(w.readframes(w.getnframes()));cache[name]=data
        start=round(when*rate)
        for i,s in enumerate(cache[name]):
            if start+i<len(samples):samples[start+i]+=round(s*.55)
    clipped=array('h',(max(-32768,min(32767,s)) for s in samples))
    with wave.open(str(path),'wb') as out:
        out.setparams((1,2,rate,len(clipped),'NONE','not compressed'))
        out.writeframes(clipped.tobytes())

def record():
    import pico2d as p
    import pico2d.pico2d as api
    from sdl2 import SDL_RenderReadPixels,SDL_PIXELFORMAT_ARGB8888,SDL_RenderSetVSync
    from main import App,INK,MUTED,CYAN,PURPLE,PAPER
    app=App(argparse.Namespace(smoke=True,smoke_scene='title',smoke_room=1,capture=None))
    SDL_RenderSetVSync(api.renderer,0)
    app.muted=True
    ffmpeg=next((WORKSPACE/'work'/'video-deps'/'imageio_ffmpeg'/'binaries').glob('ffmpeg*.exe'))
    raw=WORK/'video-only.mp4'
    log=(WORK/'encode.log').open('w',encoding='utf-8')
    command=[str(ffmpeg),'-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pixel_format','bgra',
      '-video_size','1280x800','-framerate',str(FPS),'-i','pipe:0','-an',
      '-vf','scale=1152:720:flags=lanczos,pad=1280:720:64:0:color=0xFAF8F1',
      '-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(raw)]
    encoder=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
    pixels=(ctypes.c_ubyte*(1280*800*4))()
    events=[]
    position=0
    reports=[]
    snapshots={'movement':2.8,'combat':4.7,'free':4.5,'gravity':8.4,'time':5.0,'knife':6.5}
    try:
        for index,(name,seconds) in enumerate(SCENES):
            demo=Demo(name)
            print('Rendering '+name,flush=True)
            for frame in range(seconds*FPS):
                t=frame/FPS
                demo.step(frame)
                app.game=demo.g
                app.mouse=demo.aim
                app.ui_time=(position+frame)/FPS
                app.background()
                if name in ('intro','outro'):
                    app.rect(78,156,1200,665,PAPER,True)
                    app.text('ESCAPE DIMENSION',108,602,42,INK)
                    if name=='intro':
                        app.text('핵심 기능만 따라가는 튜토리얼 시연',111,540,32,CYAN)
                        lines=['이동과 전투에서 차원 전환, 시간 조작까지',
                               '설명하는 기능을 장면별로 직접 실행합니다.',
                               '전체 화면과 게임 규칙은 Python + pico2d의 2D입니다.']
                    else:
                        app.text('같은 공간에서 전투 방법을 바꿉니다',111,540,32,PURPLE)
                        lines=['2D  좌우 이동·점프·낙하 공격',
                               '3D  8방향 이동·우회·상자 배치',
                               '4D  움직임에 따른 정지·과거 위치 선택']
                    for j,line in enumerate(lines):app.text(line,112,446-j*59,23,INK)
                    app.text('현재 3주차  /  4주차 시간 조작까지 선행 구현',112,214,23,MUTED)
                else:
                    clear,grace=demo.g.clear,demo.g.grace
                    demo.g.clear=False
                    demo.g.grace=0
                    app.world();app.hud()
                    demo.g.clear=clear
                    demo.g.grace=grace
                    app.rect(79,550,1200,666,PAPER,True)
                    app.text(TITLE[name],98,638,26,INK)
                    app.text(demo.caption,98,604,20,MUTED)
                    app.text('입력: '+(demo.keys or '없음 / 동작 확인'),98,574,18,PURPLE if name=='time' else CYAN)
                    if name=='time' and 3.2<=t<11.2:
                        app.text(f'{demo.g.time_left:04.1f}s / 10s',970,638,26,PURPLE)
                        app.text('WORLD PAUSED' if demo.g.time_frozen else 'WORLD MOVING',954,574,16,PURPLE)
                app.rect(76,9,1204,13,(220,221,214),True)
                app.rect(76,9,76+1128*(position+frame)/(90*FPS),13,CYAN,True)
                if SDL_RenderReadPixels(api.renderer,None,SDL_PIXELFORMAT_ARGB8888,pixels,1280*4)!=0:
                    raise RuntimeError('Frame read failed')
                encoder.stdin.write(bytes(pixels))
                if name in snapshots and frame==round(snapshots[name]*FPS):
                    app.screenshot(str(WORK/(name+'.png')))
                if name=='time' and frame==12*FPS:app.screenshot(str(WORK/'rewind.png'))
                p.update_canvas()
                # Consume only this game's window events so the window stays responsive.
                if any(e.type==p.SDL_QUIT for e in p.get_events()):raise KeyboardInterrupt('Recording cancelled')
            reports.append(demo.verify())
            events.extend((position/FPS+when,event) for when,event in demo.audio)
            position+=seconds*FPS
        encoder.stdin.close()
        if encoder.wait()!=0:raise RuntimeError('Video encode failed; see encode.log')
    finally:
        if encoder.poll() is None:encoder.kill()
        log.close()
        app.motion_atlases.clear()
        del app.atlas,app.characters
        p.close_canvas()
    assert position==2700
    assert all(r['status']=='pass' for r in reports),reports
    mix_audio(events,WORK/'effects.wav')
    output=WORKSPACE/'outputs'/'Escape_Dimension_발표용_튜토리얼_90초.mp4'
    subprocess.run([str(ffmpeg),'-hide_banner','-loglevel','warning','-y','-i',str(raw),'-i',str(WORK/'effects.wav'),
                    '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k',
                    '-t','90','-movflags','+faststart',str(output)],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    (WORK/'recording-verification.json').write_text(json.dumps({'frames':position,'fps':FPS,'seconds':90,
        'output':str(output),'scenes':reports},indent=2),encoding='utf-8')
    print(json.dumps({'output':str(output),'frames':position,'seconds':90}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--record',action='store_true')
    args=parser.parse_args()
    if not preflight():raise SystemExit(1)
    if args.record:record()
