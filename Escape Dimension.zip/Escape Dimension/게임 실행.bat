@echo off
chcp 65001 >nul
cd /d "%~dp0게임"
call "실행.bat"
