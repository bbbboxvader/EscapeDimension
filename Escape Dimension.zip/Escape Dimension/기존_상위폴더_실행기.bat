@echo off
chcp 65001 >nul
cd /d "%~dp0Escapse Dimension"
call "실행.bat"
